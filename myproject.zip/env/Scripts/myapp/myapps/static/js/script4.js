document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('contactForm');
    const formFeedback = document.getElementById('formFeedback');
    
    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent actual form submission
        
        // Clear previous feedback
        formFeedback.textContent = '';
        formFeedback.className = '';
        
        // Validate form fields
        let isValid = true;
        
        const name = document.getElementById('name');
        const email = document.getElementById('email');
        const message = document.getElementById('message');
        
        if (name.value.trim() === '') {
            document.getElementById('nameError').style.display = 'block';
            isValid = false;
        } else {
            document.getElementById('nameError').style.display = 'none';
        }
        
        if (!validateEmail(email.value)) {
            document.getElementById('emailError').style.display = 'block';
            isValid = false;
        } else {
            document.getElementById('emailError').style.display = 'none';
        }
        
        if (message.value.trim() === '') {
            document.getElementById('messageError').style.display = 'block';
            isValid = false;
        } else {
            document.getElementById('messageError').style.display = 'none';
        }
        
        if (isValid) {
            formFeedback.textContent = 'Thank you for your message! We will get back to you soon.';
            formFeedback.className = 'success';
            form.reset(); // Reset the form
        } else {
            formFeedback.textContent = 'Please correct the errors above.';
            formFeedback.className = 'error-message';
        }
    });
    
    function validateEmail(email) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailPattern.test(email);
    }
});
