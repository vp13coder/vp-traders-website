/* static/js/p&s.js */

function toggleInfo(serviceId) {
    const moreInfo = document.getElementById(serviceId);
    if (moreInfo.style.display === "block") {
        moreInfo.style.display = "none";
    } else {
        moreInfo.style.display = "block";
    }
}

function toggleServiceInfo(productId) {
    const moreInfo = document.getElementById(productId);
    if (moreInfo.style.display === "block") {
        moreInfo.style.display = "none";
    } else {
        moreInfo.style.display = "block";
    }
}
