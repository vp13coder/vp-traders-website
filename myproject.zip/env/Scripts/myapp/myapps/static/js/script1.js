// static/js/script.js

// Carousel functionality
const carouselInner = document.querySelector('.carousel-inner');
let index = 0;
const items = document.querySelectorAll('.carousel-item');
const interval = 5000; // 5 seconds

function nextSlide() {
    index = (index + 1) % items.length;
    carouselInner.style.transform = `translateX(-${index * 100}%)`;
}

setInterval(nextSlide, interval);

// Pop-up functionality
const popup = document.getElementById('popup');
const welcomeText = document.getElementById('welcomeText');

function hidePopup() {
    popup.style.display = 'none';
    document.body.style.overflow = 'auto'; // Restore scrollbars
    welcomeText.classList.add('animate');
}

// Show pop-up and hide it after 5 seconds
window.onload = () => {
    setTimeout(() => {
        hidePopup();
    }, 5000); // 5 seconds delay
};
