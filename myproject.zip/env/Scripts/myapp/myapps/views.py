

from django.shortcuts import render
from .models import TimelineEntry

def aboutus(request):
    timeline_entries = TimelineEntry.objects.all().order_by('date')
    return render(request, 'aboutus.html', {'timeline_entries': timeline_entries})

def index(request):
    return render(request, 'index.html')



def pands(request):
    return render(request, 'pands.html')

def contact(request):
    return render(request, 'contact.html')

from django.shortcuts import render, redirect
from .forms import ContactForm

def contact_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request, 'contact_success.html')  # Redirect to a success page
    else:
        form = ContactForm()

    return render(request, 'contact.html', {'form': form})



