// static/js/script2.js
document.addEventListener('DOMContentLoaded', () => {
    const timelineItems = document.querySelectorAll('.timeline-item');
    let currentIndex = 0;

    function showItem(index) {
        timelineItems.forEach((item, i) => {
            item.classList.toggle('show', i === index);
        });
    }

    function nextItem() {
        showItem(currentIndex);
        currentIndex = (currentIndex + 1) % timelineItems.length; // Loop back to the first item
    }

    // Show the first item initially
    showItem(currentIndex);
    currentIndex++;

    // Show each item one by one and loop indefinitely
    setInterval(nextItem, 3000); // Change item every 3 seconds
});
