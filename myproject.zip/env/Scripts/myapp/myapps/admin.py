

from django.contrib import admin
from .models import ContactMessage
from .models import TimelineEntry


@admin.register(ContactMessage)
class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ('name', 'email','message', 'submitted_at')
    search_fields = ('name', 'email')




@admin.register(TimelineEntry)
class TimelineEntryAdmin(admin.ModelAdmin):
    list_display = ('date', 'title')
    search_fields = ('title',)
